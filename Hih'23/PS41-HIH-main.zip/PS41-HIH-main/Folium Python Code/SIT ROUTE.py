import openrouteservice as ors
import folium
from pprint import pprint

client = ors.Client(key="")
M = folium.Map(location=[12.960398038535134, 80.05749724792283],
               zoom_start=16.5)
M.get_root().html.add_child(folium.Element('<style>.leaflet-control-attribution { display: none !important; }</style>'))
cord = [list(reversed([12.960248193670903, 80.05907105646034])),
        list(reversed([12.959037011705298, 80.05597586735517]))]
route = client.directions(coordinates=cord,
                          profile='foot-walking',
                          format='geojson', alternative_routes={"target_count": 2})
pprint(route)

route_lst = []
for routes in route['features']:
    cord_sum = {"coord": [list(reversed(coord)) for coord in routes['geometry']['coordinates']],
                "sum": routes['properties']['summary']}
    route_lst.append(cord_sum)
print(route_lst)
for routelst in route_lst:
    folium.PolyLine(locations=routelst["coord"],
                    color="blue").add_to(M)
    print(routelst["sum"])

M.save("route.html")
