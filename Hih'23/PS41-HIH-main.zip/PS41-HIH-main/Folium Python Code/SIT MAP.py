import folium

M = folium.Map(location=[12.960398038535134, 80.05749724792283],
               zoom_start=16.5)
M.fit_bounds([(12.963056223242935, 80.05312340323725), (12.958375674947833, 80.06030018062641)])
M.get_root().html.add_child(folium.Element('<style>.leaflet-control-attribution { display: none !important; }</style>'))

folium.Marker(location=[12.95834520991753, 80.05899478862496],
              tooltip="Sri Sairam Siddha Medical College And Hospital").add_to(M)
folium.Marker(location=[12.958338243109237, 80.05884767509248],
              tooltip="Sri Sai Ram Homoeopathy Medical College & Research Centre").add_to(M)
folium.Marker(location=[12.95796132195143, 80.05885921843048],
              tooltip="Sri Sairam Ayurveda Medical College and Research Centre").add_to(M)
folium.Marker(location=[12.9581752870413, 80.05881569384435],
              tooltip="Sri Sairam Medical College Botanical Gardens").add_to(M)
folium.Marker(location=[12.957979324028747, 80.05887878444689], tooltip="Sri Sairam  Medical ").add_to(M)
folium.Marker(location=[12.958247205779454, 80.05867326557309],
              tooltip="Sri Sairam health consultancy of Ayurveda medicine").add_to(M)
folium.Marker(location=[12.958043420297113, 80.05819775075983], tooltip="Sri Sairam Medical College Lab").add_to(M)
folium.Marker(location=[12.95825830538372, 80.05754467412159], tooltip="Leo Muthu indoor stadium").add_to(M)
folium.Marker(location=[12.959244685655248, 80.05839038260635], tooltip="Sri Sai Baba Mandir").add_to(M)
folium.Marker(location=[12.959902358822395, 80.05921001515088], tooltip="Canteen").add_to(M)
folium.Marker(location=[12.960248193670903, 80.05907105646034], tooltip="Sairam Petrol Pump").add_to(M)
folium.Marker(location=[12.960974501773281, 80.05906733136968], tooltip="Vehicle Parking").add_to(M)
folium.Marker(location=[12.962318243927832, 80.05990332215163], tooltip="Sri Sairam Polytechnic College").add_to(M)
folium.Marker(location=[12.96293555763609, 80.06048954559675], tooltip="Bus Depot-2").add_to(M)
folium.Marker(location=[12.963046857517188, 80.06016480736075],
              tooltip="SILAII PTV LTD Sairam engineering College").add_to(M)
folium.Marker(location=[12.963094313780857, 80.05937063652617], tooltip="Sairam PG Hostel ").add_to(M)
folium.Marker(location=[12.9631288637701, 80.05871022100555], tooltip="Sairam Polytechnic Labs").add_to(M)
folium.Marker(location=[12.963225828179098, 80.05632461840659], tooltip="SIT Play Ground").add_to(M)
folium.Marker(location=[12.963048452097745, 80.05305012385445], tooltip="Sri Ananda Sai Dhyana Mandapam").add_to(M)
folium.Marker(location=[12.962770301528055, 80.05424479610386],
              tooltip="Mechanical Block, Sri Sai Ram Institute Of Technology").add_to(M)
folium.Marker(location=[12.96248616510234, 80.05782726714618],
              tooltip="Sairam Matriculation Higher Secondary School").add_to(M)
folium.Marker(location=[12.961216459975349, 80.0523069836107], tooltip="Cybersecurity 1st Year").add_to(M)
folium.Marker(location=[12.960501238849877, 80.05233249024457], tooltip="Mechanical 1st year").add_to(M)
folium.Marker(location=[12.960661299558446, 80.05300450966274], tooltip="CSE 2nd Year").add_to(M)
folium.Marker(location=[12.960659655106065, 80.0532297975862], tooltip="Sri Sairam Institute of Technology").add_to(M)
folium.Marker(location=[12.960026697743924, 80.05273067574258],
              tooltip="Department of computer and communication engineering").add_to(M)
folium.Marker(location=[12.960233973170766, 80.053738562687], tooltip="Vehicle Parking").add_to(M)
folium.Marker(location=[12.960251645378879, 80.0545680365444], tooltip="Grave Yard, sairam college").add_to(M)
folium.Marker(location=[12.95974844316413, 80.05243704446737], tooltip="Sairaj Press").add_to(M)
folium.Marker(location=[12.95930940809351, 80.05246702019303], tooltip="SIT College Canteen").add_to(M)
folium.Marker(location=[12.959264747190064, 80.0544856183319], tooltip="SEC Cricket Ground").add_to(M)
folium.Marker(location=[12.959037011705298, 80.05597586735517], tooltip="Sairam Girls Hostel").add_to(M)
folium.Marker(location=[12.95891650165782, 80.05635696839798], tooltip="Sairam Girls Hostel-2").add_to(M)
folium.Marker(location=[12.959572888811381, 80.0560673081778], tooltip="Block-A").add_to(M)
folium.Marker(location=[12.959522522902567, 80.05662079870393], tooltip="SIGMA Auditorium").add_to(M)
folium.Marker(location=[12.960132207105781, 80.05743650178867], tooltip="Sri Sairam Engineering College").add_to(M)
folium.Marker(location=[12.960354288710166, 80.05759076680658], tooltip="CSBS lab").add_to(M)
folium.Marker(location=[12.960278150810504, 80.05794187099526], tooltip="Machines Lab").add_to(M)
folium.Marker(location=[12.96051415957627, 80.05787078586444], tooltip="Class AIML").add_to(M)
folium.Marker(location=[12.96062274017969, 80.05766052082973], tooltip="Department Of Information Technology").add_to(M)
folium.Marker(location=[12.960857582827332, 80.05806738173983], tooltip="Mech B").add_to(M)
folium.Marker(location=[12.96117597447385, 80.05832218175553], tooltip="D-Block").add_to(M)
folium.Marker(location=[12.960754216304458, 80.05689307983202], tooltip="AI-DS Department").add_to(M)
folium.Marker(location=[12.960713398731246, 80.05716035893258], tooltip="EIE Department").add_to(M)
folium.Marker(location=[12.96094294113494, 80.05736005195637], tooltip="Sri Sai Ram Siddha Medical College").add_to(M)
folium.Marker(location=[12.961070655104841, 80.05800348263472], tooltip="Sri Sairam Institutions").add_to(M)
folium.Marker(location=[12.960483683128844, 80.05569286991363], tooltip="Boys Hostel-1").add_to(M)
folium.Marker(location=[12.961052900961649, 80.05602350268664], tooltip="Boys Hostel-2").add_to(M)
folium.Marker(location=[12.96026853399027, 80.05605932582864], tooltip="Mechanical Workshop").add_to(M)
folium.Marker(location=[12.961384394088089, 80.05652185580757], tooltip="Sairam Boys Dining Hall-1").add_to(M)
folium.Marker(location=[12.961522444139712, 80.05642705392373], tooltip="Sairam Boys Dining Hall-2").add_to(M)
folium.Marker(location=[12.961693814457751, 80.05675162373663], tooltip="The Rocketeer Racing").add_to(M)
folium.Marker(location=[12.961352503374453, 80.05724356434919], tooltip="Dr.Kalam Digital Library").add_to(M)
folium.Marker(location=[12.96136443045494, 80.05708820315299], tooltip="RRRC Canteen").add_to(M)
folium.Marker(location=[12.961975635548518, 80.05686704857325],
              tooltip="Department of Mechanical Engineering,Sri Sairam Engineering College").add_to(M)
folium.Marker(location=[12.961867619992788, 80.05727490908498],
              tooltip="Sri Sairam Techno Incubator Foundation").add_to(M)
folium.Marker(location=[12.96183555682056, 80.05747953938679], tooltip="Armor Grandeur, Private Limited").add_to(M)
folium.Marker(location=[12.95949630420456, 80.05710256382078], tooltip="Basket Ball Court").add_to(M)
folium.Marker(location=[12.95942924121318, 80.05741993726365], tooltip="Sri Sairam Sports Arena").add_to(M)
folium.Marker(location=[12.961465008199674, 80.05401361451888], tooltip=" SIT Basket Ball Court").add_to(M)
folium.Marker(location=[12.961521311824574, 80.05428719347276], tooltip="SIT Sports Arena").add_to(M)

M.save("SIT-Map.html")
