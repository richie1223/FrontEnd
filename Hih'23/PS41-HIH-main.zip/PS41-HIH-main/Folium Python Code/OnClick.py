import folium


def find_popup_slice(html):
    '''
    Find the starting and edning index of popup function
    '''

    pattern = "function latLngPop(e)"

    # startinf index
    starting_index = html.find(pattern)

    #
    tmp_html = html[starting_index:]

    #
    found = 0
    index = 0
    opening_found = False
    while not opening_found or found > 0:
        if tmp_html[index] == "{":
            found += 1
            opening_found = True
        elif tmp_html[index] == "}":
            found -= 1

        index += 1

    # determine the edning index of popup function
    ending_index = starting_index + index

    return starting_index, ending_index


def find_variable_name(html, name_start):
    variable_pattern = "var "
    pattern = variable_pattern + name_start

    starting_index = html.find(pattern) + len(variable_pattern)
    tmp_html = html[starting_index:]
    ending_index = tmp_html.find(" =") + starting_index

    return html[starting_index:ending_index]


def custom_code(map_variable_name):
    return '''
            // custom code
            function latLngPop(e) {
                console.log("Latitude: " + e.latlng.lat.toFixed(4));
                console.log("Longitude: " + e.latlng.lng.toFixed(4));

                L.marker(
                    [e.latlng.lat, e.latlng.lng],
                    {}
                ).addTo(%s);
            }
            // end custom code
    ''' % (map_variable_name)


# create folium map
M = folium.Map(location=[12.960398038535134, 80.05749724792283],zoom_start=16.5)
map_filepath="OnClick.html"
# add popup
folium.LatLngPopup().add_to(M)

# convert map object into html
html=M.get_root().render()

# find variable names
map_variable_name = find_variable_name(html, "map_")
popup_variable_name = find_variable_name(html, "lat_lng_popup_")

# determine popup function indicies
pstart, pend = find_popup_slice(html)

# inject code
map_html = html[:pstart] + custom_code(map_variable_name) + html[pend:]

# save as html
map_html_file= open("OnClick.html","w")
map_html_file.write(map_html)
map_html_file.close()
